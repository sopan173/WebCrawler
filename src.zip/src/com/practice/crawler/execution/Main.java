package com.practice.crawler.execution;

import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.practice.crawler.database.Database;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Main {
    public static Database db = new Database();

    public static void main(String[] args) throws SQLException, IOException {
        db.runSql2("TRUNCATE Record;"); //removing all records fro table
        processPage("http://www.ncert.nic.in");
    }

    //writing recursive method to process each page
    public static void processPage(String URL) throws SQLException, IOException{
        //check if the given URL is already in database
        String sql = "select * from Record where URL = '"+URL+"'";
        ResultSet rs = db.runSql(sql);
        if(rs.next()){

        }else{
            //store URL to database to avoid parsing again and again

            sql = "INSERT INTO  `WebCrawler`.`Record` " + "(`URL`) VALUES " + "(?);";
            PreparedStatement stmt = db.conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, URL);
            stmt.execute();

            //extrct required info
            Document doc = Jsoup.connect("http://ncert.nic.in/").get();
            System.out.println("Testing Document - ");
            System.out.println(doc);
            if(doc.text().contains("textbook")){
                System.out.println(URL);
            }

            //get all links and recursively call the processPage method
            Elements questions = doc.select("a[href]");
            for(Element link: questions){
                if(link.attr("href").contains("pdf"))
                    processPage(link.attr("abs:href"));
            }
        }
    }
}